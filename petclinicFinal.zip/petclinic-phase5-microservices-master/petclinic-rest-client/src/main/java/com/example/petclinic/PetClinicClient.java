package com.example.petclinic;

import com.example.petclinic.business.PetClinicBusinessWorkflow;
import org.apache.catalina.core.ApplicationContext;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import javax.swing.*;

@SpringBootApplication
public class PetClinicClient {

    public static void main(String[] args) {

        ConfigurableApplicationContext context= SpringApplication.run(PetClinicClient.class, args);

        PetClinicBusinessWorkflow business = (PetClinicBusinessWorkflow) context.getBean("petClinicBusinessWorkflow");

        business.runBusiness();
    }
}
