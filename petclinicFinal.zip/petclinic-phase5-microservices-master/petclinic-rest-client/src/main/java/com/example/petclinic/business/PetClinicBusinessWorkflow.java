package com.example.petclinic.business;

import com.example.petclinic.model.Owner;
import com.example.petclinic.service.OwnerService;
import org.springframework.stereotype.Component;
@Component
public class PetClinicBusinessWorkflow {
    OwnerService ownerService;

    public PetClinicBusinessWorkflow(OwnerService ownerservice) {
        this.ownerService = ownerservice;
    }
    public void runBusiness(){



        Owner.OwnerBuilder owner1 = Owner.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity( "Springfield").withPhoneNumber("9395550113");
        Owner.OwnerBuilder owner2 = Owner.builder().withName("Marge Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113");
        Owner.OwnerBuilder owner3 = Owner.builder().withName("Lisa Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber( "9395550113");
        Owner.OwnerBuilder owner4 = Owner.builder().withName("Bart Simpson").withAddress("742 Evergreen Terrace").withCity( "Springfield").withPhoneNumber("9395550113");


        //Finish flushing out the PET!!!
       /** Pet.PetBuilder pet1 = Pet.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity( "Springfield").withPhoneNumber("9395550113");
        Pet.PetBuilder pet2 = Pet.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity( "Springfield").withPhoneNumber("9395550113");
        Pet.PetBuilder pet1 = Pet.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity( "Springfield").withPhoneNumber("9395550113");
        Pet.PetBuilder pet1 = Pet.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity( "Springfield").withPhoneNumber("9395550113");
        // save owners to database  */

        OwnerService.saveOwner(owner1);
        OwnerService.saveOwner(owner2);
        OwnerService.saveOwner(owner3);
        OwnerService.saveOwner(owner4);

        /**
        PetService.savePet(pet1);
        PetService.savePet(pet2);
        PetService.savePet(pet3);
        PetService.savePet(pet4);   */

        // get all owners from database and display them



    }
}
