package com.example.petclinic.service;

import com.example.petclinic.model.Pet;
import com.example.petclinic.restclient.Application;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

public class PetService {
    private static final Logger log = LoggerFactory.getLogger(Application.class);


    RestTemplate restTemplate;


    public PetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }


    public PetService savePet(Pet pet){

        URI uri = URI.create("http://localhost:8082/petapi/pet/addPet");

        PetService response = restTemplate.postForObject(uri, pet, PetService.class);
        log.info(response.toString());
        return response;
    }

}
