package com.example.petclinic.business;

import com.example.petclinic.model.Owner;
import com.example.petclinic.service.OwnerService;
import org.springframework.stereotype.Component;

@Component
public class PetClinicBusinessWorkflow {
    OwnerService ownerService;

    public PetClinicBusinessWorkflow(OwnerService ownerservice) {
        this.ownerService = ownerservice;
    }

    public void runBusiness() {


        Owner owner1 = Owner.builder().withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
        Owner owner2 = Owner.builder().withName("Marge Simpson").withAddress("743 Evergreen Terrace").withCity("Stringfield").withPhoneNumber("9395550114").build();
        Owner owner3 = Owner.builder().withName("Lisa Simpson").withAddress("744 Evergreen Terrace").withCity("Sbringfield").withPhoneNumber("9395550115").build();
        Owner owner4 = Owner.builder().withName("Bart Simpson").withAddress("745 Evergreen Terrace").withCity("Svringfield").withPhoneNumber("9395550116").build();

        // save owners to database
        ownerService.addOwners(owner1);
        ownerService.addOwners(owner2);
        ownerService.addOwners(owner3);
        ownerService.addOwners(owner4);

        ownerService.deleteOwner(owner1);
        ownerService.getAllOwners();




    }
}
