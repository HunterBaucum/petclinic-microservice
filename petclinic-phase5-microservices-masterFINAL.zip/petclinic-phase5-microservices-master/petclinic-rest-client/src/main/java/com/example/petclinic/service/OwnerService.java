package com.example.petclinic.service;

import com.example.petclinic.model.Owner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Service
public class OwnerService {

    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }


    public Owner addOwners(Owner owner) {

        URI uri = URI.create("http://localhost:9091/ownerapi/owner/addOwners");
        Owner response = restTemplate.postForObject(uri, owner, Owner.class);
        log.info(owner.toString());
        return response;
    }

    public Owner[] getAllOwners() {

        URI uri = URI.create("http://localhost:9091/ownerapi/owner/getAllOwners");
        ResponseEntity<Owner[]> responseEntity = restTemplate.getForEntity(uri, Owner[].class);
        Owner[] response = responseEntity.getBody();
        for (Owner o : response)
            log.info(o.toString());
        return response;
    }

    public void deleteOwner(Owner owner) {

        URI uri = URI.create("http://localhost:9091/ownerapi/owner/deleteOwner");

        HttpEntity<Owner> entity = new HttpEntity<>(owner);
        restTemplate.exchange(uri, HttpMethod.DELETE, entity, String.class);
        log.info("DELETE" + owner.toString());
        return;
    }

    public void modifyOwner(Owner owner) {

        URI uri = URI.create("http://localhost:9091/ownerapi/owner/modifyOwner");

        HttpEntity<Owner> entity = new HttpEntity<>(owner);
        restTemplate.exchange(uri, HttpMethod.DELETE, entity, String.class);

    }

    public List<Owner> getOwnerByName(String name) {
        String uriName = name.replaceAll("", "%20");
        URI uri = URI.create("http://localhost:9091/ownerapi/owner/getOwnerByName/" + uriName);
        List<Owner> response = restTemplate.getForObject(uri, List.class);
        log.info(response.toString());
        return response;

    }

    public void deleteOwner(Owner.OwnerBuilder owner) {
    }

    public void addOwner(Owner.OwnerBuilder owner) {

    }


}

